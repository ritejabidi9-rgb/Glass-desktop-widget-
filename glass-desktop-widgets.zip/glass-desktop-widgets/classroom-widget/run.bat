@echo off
cd /d "%~dp0"
set PY=
where py >nul 2>nul && set PY=py
if not defined PY where python >nul 2>nul && set PY=python
if not defined PY (
  echo Python was not found. Install it from python.org and tick "Add Python to PATH".
  pause
  exit /b
)
echo Using %PY%
echo Installing libraries (first time only)...
%PY% -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo Install failed. Screenshot this window and include it when you report the problem on GitHub.
  pause
  exit /b
)
echo.
echo Starting widget. Keep this window open while testing.
%PY% files_widget.py
echo.
echo The widget stopped. If there is an error above, screenshot it and open an issue on GitHub.
pause
