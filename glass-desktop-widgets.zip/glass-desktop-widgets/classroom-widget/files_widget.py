import sys, os, json, re, threading, webbrowser
from datetime import datetime, timezone
from PyQt6.QtCore import Qt, QTimer, QRectF, QPointF, QObject, pyqtSignal
from PyQt6.QtGui import QPainter, QColor, QPen, QFont, QFontMetrics, QPainterPath, QGuiApplication
from PyQt6.QtWidgets import QApplication, QWidget, QFileDialog, QMenu

os.environ["OAUTHLIB_RELAX_TOKEN_SCOPE"] = "1"
HERE = os.path.dirname(os.path.abspath(__file__))
CONFIG = os.path.join(HERE, "widget_config.json")
CREDS = os.path.join(HERE, "credentials.json")
TOKEN = os.path.join(HERE, "token.json")
SCOPES = [
    "https://www.googleapis.com/auth/classroom.courses.readonly",
    "https://www.googleapis.com/auth/classroom.coursework.me.readonly",
    "https://www.googleapis.com/auth/classroom.courseworkmaterials.readonly",
    "https://www.googleapis.com/auth/classroom.announcements.readonly",
]
RECENT_DIR = os.path.join(os.environ.get("APPDATA", ""), "Microsoft", "Windows", "Recent")
BASE_W, BASE_H, EDGE = 380, 290, 8


def load_cfg():
    try:
        with open(CONFIG, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_cfg(cfg):
    try:
        with open(CONFIG, "w", encoding="utf-8") as f:
            json.dump(cfg, f)
    except Exception:
        pass


def rel(iso):
    try:
        t = datetime.fromisoformat(re.sub(r"\.\d+", "", iso).replace("Z", "+00:00"))
        s = (datetime.now(timezone.utc) - t).total_seconds()
        if s < 3600: return f"{max(1, int(s // 60))}m ago"
        if s < 86400: return f"{int(s // 3600)}h ago"
        if s < 7 * 86400: return f"{int(s // 86400)}d ago"
        return t.astimezone().strftime("%d %b")
    except Exception:
        return ""


def get_recent(limit=12):
    out = []
    try:
        entries = [e for e in os.scandir(RECENT_DIR) if e.name.lower().endswith(".lnk")]
        entries.sort(key=lambda e: e.stat().st_mtime, reverse=True)
        for e in entries:
            name = e.name[:-4]
            if "." in name:
                out.append((name, e.path))
            if len(out) >= limit:
                break
    except Exception:
        pass
    return out


def get_service():
    from google.oauth2.credentials import Credentials
    from google.auth.transport.requests import Request
    from google_auth_oauthlib.flow import InstalledAppFlow
    from googleapiclient.discovery import build
    creds = None
    if os.path.exists(TOKEN):
        creds = Credentials.from_authorized_user_file(TOKEN, SCOPES)
    if creds and creds.expired and creds.refresh_token:
        creds.refresh(Request())
    if not creds or not creds.valid:
        creds = InstalledAppFlow.from_client_secrets_file(CREDS, SCOPES).run_local_server(port=0)
    with open(TOKEN, "w", encoding="utf-8") as f:
        f.write(creds.to_json())
    return build("classroom", "v1", credentials=creds, cache_discovery=False)


def fetch_classroom(interactive):
    if not os.path.exists(CREDS):
        return "nocreds", None
    if not os.path.exists(TOKEN) and not interactive:
        return "connect", None
    try:
        svc = get_service()
        courses = svc.courses().list(studentId="me", courseStates=["ACTIVE"], pageSize=20).execute().get("courses", [])
        items = []
        for c in courses:
            cid, cname = c["id"], c.get("name", "Class")
            try:
                for w in svc.courses().courseWork().list(courseId=cid, orderBy="updateTime desc", pageSize=5).execute().get("courseWork", []):
                    items.append(dict(title=w.get("title", "Assignment"), link=w.get("alternateLink"), t=w.get("updateTime", ""), sub=cname, kind="Assignment"))
            except Exception:
                pass
            try:
                for m in svc.courses().courseWorkMaterials().list(courseId=cid, orderBy="updateTime desc", pageSize=5).execute().get("courseWorkMaterial", []):
                    items.append(dict(title=m.get("title", "Material"), link=m.get("alternateLink"), t=m.get("updateTime", ""), sub=cname, kind="Material"))
            except Exception:
                pass
            try:
                for a in svc.courses().announcements().list(courseId=cid, orderBy="updateTime desc", pageSize=5).execute().get("announcements", []):
                    if a.get("materials"):
                        txt = (a.get("text") or "New post with files").strip().replace("\n", " ")
                        items.append(dict(title=txt[:60], link=a.get("alternateLink"), t=a.get("updateTime", ""), sub=cname, kind="Post"))
            except Exception:
                pass
        items.sort(key=lambda x: x["t"], reverse=True)
        for it in items:
            it["sub"] = " · ".join(p for p in (it["sub"], it["kind"], rel(it["t"])) if p)
        return "ok", items[:15]
    except Exception as e:
        msg = str(e)
        try:
            from googleapiclient.errors import HttpError
            if isinstance(e, HttpError):
                msg = f"{e.resp.status}: {e._get_reason()}"
        except Exception:
            pass
        try:
            import traceback
            with open(os.path.join(HERE, "error.log"), "w", encoding="utf-8") as f:
                f.write(traceback.format_exc())
        except Exception:
            pass
        low = msg.lower()
        if ("scope" in low or "invalid_grant" in low) and os.path.exists(TOKEN):
            os.remove(TOKEN)
        return "error", msg[:220]


class Bus(QObject):
    done = pyqtSignal(str, object)


class FilesWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.cfg = load_cfg()
        self.cfg.setdefault("pinned", []); self.cfg.setdefault("theme", "glass"); self.cfg.setdefault("mode", "classroom")
        self.hover, self.drag, self.busy = -1, None, False
        self.state, self.cl_items, self.recent = "loading", [], get_recent()
        self.err = ""
        self.bus = Bus(); self.bus.done.connect(self.on_done)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool | Qt.WindowType.WindowStaysOnBottomHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setMouseTracking(True)
        self.setMinimumSize(300, 200)
        w, h = self.cfg.get("size", [BASE_W, BASE_H])
        self.resize(w, h)
        pos = self.cfg.get("pos")
        if pos:
            self.move(pos[0], pos[1])
        else:
            g = QGuiApplication.primaryScreen().availableGeometry()
            self.move(g.right() - w - 24, g.bottom() - h - 24)
        self.save_t = QTimer(self); self.save_t.setSingleShot(True); self.save_t.timeout.connect(self.save_geom)
        for ms, fn in ((3000, self.refresh_local), (2500, self.lower), (300000, self.start_fetch)):
            t = QTimer(self); t.timeout.connect(fn); t.start(ms)
        self.start_fetch()

    def save_geom(self):
        self.cfg["size"] = [self.width(), self.height()]; self.cfg["pos"] = [self.x(), self.y()]; save_cfg(self.cfg)

    def resizeEvent(self, e):
        self.save_t.start(600)

    def start_fetch(self, interactive=False):
        if self.busy or self.cfg["mode"] != "classroom":
            return
        self.busy = True
        if not self.cl_items:
            self.state = "loading"; self.update()
        threading.Thread(target=lambda: self.bus.done.emit(*fetch_classroom(interactive)), daemon=True).start()

    def on_done(self, state, payload):
        self.busy = False; self.state = state
        if state == "ok": self.cl_items = payload
        elif state == "error": self.err = payload
        self.update()

    def refresh_local(self):
        if self.cfg["mode"] == "files":
            self.recent = get_recent(); self.update()

    def sc(self):
        return max(0.8, min(2.2, self.width() / BASE_W))

    def items(self):
        if self.cfg["mode"] == "classroom":
            return [dict(title=i["title"], sub=i["sub"], target=i["link"], pinned=False) for i in self.cl_items]
        items = [dict(title=os.path.basename(p), sub="Pinned file", target=p, pinned=True) for p in self.cfg["pinned"] if os.path.exists(p)]
        seen = {i["title"] for i in items}
        items += [dict(title=n, sub="Recent file", target=p, pinned=False) for n, p in self.recent if n not in seen]
        return items

    def geom(self):
        s = self.sc(); row = 48 * s; top = 62 * s
        n = max(1, int((self.height() - top - 56 * s) / row))
        return s, row, top, n

    def visible_items(self):
        return self.items()[: self.geom()[3]]

    def row_rect(self, i):
        s, row, top, _ = self.geom()
        return QRectF(14 * s, top + i * row, self.width() - 28 * s, row - 4 * s)

    def plus_center(self):
        s = self.sc(); return QPointF(self.width() - 44 * s, self.height() - 34 * s)

    def on_plus(self, p):
        c = self.plus_center(); r = 20 * self.sc()
        return (p.x() - c.x()) ** 2 + (p.y() - c.y()) ** 2 <= r * r

    def row_at(self, p):
        for i in range(len(self.visible_items())):
            if self.row_rect(i).contains(p): return i
        return -1

    def edge_at(self, p):
        fl = []
        if p.x() < EDGE: fl.append(Qt.Edge.LeftEdge)
        if p.x() > self.width() - EDGE: fl.append(Qt.Edge.RightEdge)
        if p.y() < EDGE: fl.append(Qt.Edge.TopEdge)
        if p.y() > self.height() - EDGE: fl.append(Qt.Edge.BottomEdge)
        if not fl: return None
        r = fl[0]
        for f in fl[1:]: r |= f
        return r

    def edge_cursor(self, e):
        L, R, T, B = Qt.Edge.LeftEdge, Qt.Edge.RightEdge, Qt.Edge.TopEdge, Qt.Edge.BottomEdge
        has = lambda f: bool(e & f)
        if (has(L) and has(T)) or (has(R) and has(B)): return Qt.CursorShape.SizeFDiagCursor
        if (has(R) and has(T)) or (has(L) and has(B)): return Qt.CursorShape.SizeBDiagCursor
        if has(L) or has(R): return Qt.CursorShape.SizeHorCursor
        return Qt.CursorShape.SizeVerCursor

    def paintEvent(self, _):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        s, row, top, n = self.geom(); W, H = self.width(), self.height()
        glass = self.cfg["theme"] == "glass"
        p.setBrush(QColor(255, 255, 255, 48) if glass else QColor(70, 6, 12, 190))
        p.setPen(QPen(QColor(255, 255, 255, 120) if glass else QColor(255, 255, 255, 70), 1.5))
        p.drawRoundedRect(QRectF(1, 1, W - 2, H - 2), 24 * s, 24 * s)
        f = QFont("Segoe UI"); f.setPointSizeF(10 * s); p.setFont(f); p.setPen(QColor(255, 255, 255, 190))
        p.drawText(QPointF(28 * s, 38 * s), "Classroom · recent uploads" if self.cfg["mode"] == "classroom" else "Recently viewed")
        items = self.visible_items()
        if not items:
            msg = {"loading": "Loading…", "connect": "Click here to connect\nGoogle Classroom",
                   "nocreds": "Add credentials.json to the\nwidget folder (see README)",
                   "error": f"Couldn't load Classroom.\n{self.err}\nClick to retry."}.get(self.state, "Nothing here yet") if self.cfg["mode"] == "classroom" else "No recent files yet"
            f.setPointSizeF(10.5 * s); p.setFont(f); p.setPen(QColor(255, 255, 255, 210))
            p.drawText(QRectF(14 * s, top, W - 28 * s, H - top - 60 * s), Qt.AlignmentFlag.AlignCenter.value | Qt.TextFlag.TextWordWrap.value, msg)
        tw = int(W - (28 + 36 + 30 + 14) * s)
        for i, it in enumerate(items):
            r = self.row_rect(i)
            if i == self.hover:
                p.setPen(Qt.PenStyle.NoPen); p.setBrush(QColor(255, 255, 255, 36)); p.drawRoundedRect(r, 12 * s, 12 * s)
            ix, iy = 28 * s, r.top() + (r.height() - 24 * s) / 2
            p.setBrush(Qt.BrushStyle.NoBrush); p.setPen(QPen(QColor(255, 255, 255, 235), 1.6 * s))
            d = QPainterPath(); d.moveTo(ix, iy + 2 * s); d.lineTo(ix + 10 * s, iy + 2 * s); d.lineTo(ix + 16 * s, iy + 8 * s)
            d.lineTo(ix + 16 * s, iy + 22 * s); d.lineTo(ix, iy + 22 * s); d.closeSubpath(); p.drawPath(d)
            p.drawLine(QPointF(ix + 10 * s, iy + 2 * s), QPointF(ix + 10 * s, iy + 8 * s))
            p.drawLine(QPointF(ix + 10 * s, iy + 8 * s), QPointF(ix + 16 * s, iy + 8 * s))
            tf = QFont("Segoe UI", 11, QFont.Weight.DemiBold); tf.setPointSizeF(11 * s)
            p.setFont(tf); p.setPen(QColor(255, 255, 255))
            p.drawText(QRectF(ix + 36 * s, r.top(), tw, r.height() / 2 + 3 * s), Qt.AlignmentFlag.AlignBottom,
                       QFontMetrics(tf).elidedText(it["title"], Qt.TextElideMode.ElideRight, tw))
            sf = QFont("Segoe UI"); sf.setPointSizeF(8.5 * s); p.setFont(sf); p.setPen(QColor(255, 255, 255, 160))
            p.drawText(QRectF(ix + 36 * s, r.top() + r.height() / 2 + 3 * s, tw, r.height() / 2), Qt.AlignmentFlag.AlignTop,
                       QFontMetrics(sf).elidedText(it["sub"], Qt.TextElideMode.ElideRight, tw))
        c = self.plus_center()
        p.setBrush(QColor(255, 255, 255, 90)); p.setPen(QPen(QColor(255, 255, 255, 170), 1.5)); p.drawEllipse(c, 18 * s, 18 * s)
        bf = QFont("Segoe UI"); bf.setPointSizeF(14 * s); p.setFont(bf); p.setPen(QColor(255, 255, 255))
        p.drawText(QRectF(c.x() - 18 * s, c.y() - 18 * s, 36 * s, 36 * s), Qt.AlignmentFlag.AlignCenter,
                   "↻" if self.cfg["mode"] == "classroom" else "+")

    def pin_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Pin a file")
        if path and path not in self.cfg["pinned"]:
            self.cfg["pinned"].insert(0, os.path.normpath(path)); save_cfg(self.cfg); self.update()

    def mouseMoveEvent(self, e):
        if self.drag is not None and e.buttons() & Qt.MouseButton.LeftButton:
            self.move(e.globalPosition().toPoint() - self.drag); return
        ed = self.edge_at(e.position())
        if ed is not None:
            self.setCursor(self.edge_cursor(ed)); return
        h = self.row_at(e.position())
        if h != self.hover: self.hover = h; self.update()
        self.setCursor(Qt.CursorShape.PointingHandCursor if (h >= 0 or self.on_plus(e.position())) else Qt.CursorShape.ArrowCursor)

    def leaveEvent(self, _):
        self.hover = -1; self.update()

    def mousePressEvent(self, e):
        pos = e.position()
        if e.button() == Qt.MouseButton.RightButton:
            self.context(e.globalPosition().toPoint(), self.row_at(pos)); return
        if e.button() != Qt.MouseButton.LeftButton: return
        ed = self.edge_at(pos)
        if ed is not None:
            self.windowHandle().startSystemResize(ed); return
        if self.on_plus(pos):
            if self.cfg["mode"] == "classroom": self.start_fetch(self.state in ("connect", "error"))
            else: self.pin_file()
            return
        i = self.row_at(pos)
        if i >= 0:
            t = self.visible_items()[i]["target"]
            try:
                if self.cfg["mode"] == "classroom": webbrowser.open(t)
                else: os.startfile(t)
            except Exception: pass
            return
        if self.cfg["mode"] == "classroom" and self.state in ("connect", "error") and not self.visible_items():
            self.start_fetch(True); return
        self.drag = e.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseReleaseEvent(self, _):
        if self.drag is not None:
            self.drag = None; self.save_geom()

    def context(self, gpos, row):
        m = QMenu(self); vis = self.visible_items()
        if self.cfg["mode"] == "classroom":
            m.addAction("Refresh", lambda: self.start_fetch(self.state in ("connect", "error")))
            m.addAction("Open Google Classroom", lambda: webbrowser.open("https://classroom.google.com"))
            m.addAction("Show recent files instead", lambda: self.set_mode("files"))
            m.addAction("Disconnect Google account", self.disconnect)
        else:
            if 0 <= row < len(vis) and vis[row]["pinned"]:
                m.addAction("Unpin this file", lambda: self.unpin(vis[row]["target"]))
            m.addAction("Pin a file…", self.pin_file)
            m.addAction("Show Classroom uploads instead", lambda: self.set_mode("classroom"))
        m.addAction("Switch style", self.toggle_theme)
        m.addSeparator(); m.addAction("Quit widget", QApplication.quit)
        m.exec(gpos)

    def set_mode(self, mode):
        self.cfg["mode"] = mode; save_cfg(self.cfg); self.update()
        if mode == "classroom": self.start_fetch()

    def disconnect(self):
        try: os.remove(TOKEN)
        except Exception: pass
        self.cl_items = []; self.state = "connect"; self.update()

    def unpin(self, path):
        self.cfg["pinned"] = [p for p in self.cfg["pinned"] if os.path.normpath(p) != os.path.normpath(path)]
        save_cfg(self.cfg); self.update()

    def toggle_theme(self):
        self.cfg["theme"] = "maroon" if self.cfg["theme"] == "glass" else "glass"; save_cfg(self.cfg); self.update()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    w = FilesWidget(); w.show()
    sys.exit(app.exec())
