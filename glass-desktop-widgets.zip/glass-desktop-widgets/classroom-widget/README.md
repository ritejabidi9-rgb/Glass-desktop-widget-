# Classroom glass widget

A resizable frosted-glass widget for your Windows desktop that shows your newest
Google Classroom uploads (assignments, materials, and posts with files).
Click an item to open it in Classroom.

## 1. Install
1. Install Python 3.10+ from python.org (tick "Add Python to PATH").
2. Double-click `run.bat` (first run installs the libraries). Keep its window open while testing; once it works, use `run_hidden.bat` for a silent start.
3. Optional: `add_to_startup.bat` makes it start with Windows.

## 2. Connect Google Classroom (one time, about 5 minutes)
Google needs you to make a free personal key, because the widget reads Classroom for you.
1. Go to console.cloud.google.com and create a project (any name).
2. Menu > APIs & Services > Library > search "Google Classroom API" > Enable.
3. APIs & Services > OAuth consent screen > choose External > fill the app name and your email > Save.
   Under "Test users", add the Google account you use for Classroom.
4. APIs & Services > Credentials > Create credentials > OAuth client ID > Application type: Desktop app > Create.
5. Click Download JSON, rename it to `credentials.json`, and put it in this folder.
6. Open the widget and click "Connect Google Classroom". Sign in and allow.
   If Google says the app isn't verified, click Advanced > continue (it's your own app).

Notes:
- While the app is in "Testing", Google asks you to reconnect about once a week.
  Press "Publish app" on the consent screen to avoid that.
- School accounts: some schools block this. If you see "access blocked", use
  right-click > "Show recent files instead".

## Using it with your own Google account (important)
This widget does **not** include anyone's Google key, and it can't: every person creates their own free key (steps above) and signs in with their own account. That keeps your data between you and Google.

**"Access blocked" / "Error 403: access_denied"?** Your app is in *Testing* mode, and Google only lets accounts on the **Test users** list sign in. Fix:
1. Open console.cloud.google.com and pick your project.
2. Go to **Google Auth Platform > Audience** (older console: **APIs & Services > OAuth consent screen**).
3. Under **Test users** click **Add users**, type the exact Gmail / school address you use for Classroom, and Save.
4. Delete `token.json` if it exists, then click "Connect Google Classroom" again.

Tips:
- Press **Publish app** on that same page so you don't have to reconnect every 7 days. Google will show an "unverified app" screen when you sign in; click **Advanced > Go to (your app name)**. It is your own key, so this is expected.
- The Google account you add must be the same one you sign in with. If you use two accounts, add both.
- School or work accounts: the administrator may block third-party apps. If so, use right-click > "Show recent files instead".

## Use
- Drag any edge or corner to resize. Everything scales with the size.
- Drag the empty parts of the card to move it.
- The round button refreshes (+ pins a file in recent-files mode).
- Right-click for style, refresh, disconnect, and quit.

## Keep your keys private
`credentials.json` and `token.json` are **secrets for your own Google account**. They stay on your PC and must never be uploaded, posted or committed to GitHub (the repo's `.gitignore` already blocks them). If they ever leak, delete the OAuth client in the Google Cloud console and revoke the app under your Google account > Security > Third-party access, then create a new key.
`widget_config.json` (position, size, theme) and `error.log` are also local files and are ignored by Git.
