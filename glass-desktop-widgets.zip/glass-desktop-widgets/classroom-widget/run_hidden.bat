@echo off
cd /d "%~dp0"
where pyw >nul 2>nul && (start "" pyw files_widget.py & exit /b)
start "" pythonw files_widget.py
