Add your screenshots here: dock.png, spotify.png, weather.png (see the main README).
