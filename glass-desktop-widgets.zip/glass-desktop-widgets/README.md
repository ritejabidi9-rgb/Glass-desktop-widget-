# Glass Desktop Widgets for Windows

Three small desktop widgets for Windows 10/11 with a glass look, written in Python (PyQt6). Rounded corners, translucent text, resizable.

| | |
|---|---|
| [**Spotify Glass Widget**](spotify-widget) | A now-playing bar with album art, progress and play / pause / next. |
| [**Weather Glass Widget**](weather-widget) | A tile with temperature, high / low and a drawn icon. |
| [**Classroom Glass Widget**](classroom-widget) | Your newest Google Classroom uploads (assignments, materials, posts with files), or recently opened files. Click an item to open it. |

<!-- Add your own screenshots to the assets folder (spotify.png, weather.png, classroom.png), then remove this comment:
![Classroom widget](assets/classroom.png)
![Spotify widget](assets/spotify.png)
![Weather widget](assets/weather.png)
-->

> **Early version.** These were built quickly and have been tested on one Windows PC. Expect rough edges, and please open an issue if something breaks (include a screenshot or the error text).

## Quick start
1. Install **Python 3.10+** from [python.org](https://www.python.org/downloads/) and tick **"Add Python to PATH"**.
2. Download this repo (green **Code** button > **Download ZIP**) and unzip it.
3. Open the folder of the widget you want and double-click **`run.bat`**. The first run installs what it needs.

Each folder has its own README with controls and settings.

## Notes
- **Windows only.** The Spotify widget reads Windows' media session.
- **Accounts:** the Spotify and weather widgets need no account or key. The Classroom widget needs a free Google key that you create yourself (steps in its README). Keep `credentials.json` and `token.json` private.
- **Smart App Control:** if Windows blocks Python or the scripts, Smart App Control only allows apps Microsoft trusts. You can allow Python through it or turn Smart App Control off (on many versions it can't be turned back on without reinstalling Windows).
- **Settings files:** the widgets save your position and options next to the scripts or in your user folder. They stay on your PC and are excluded by `.gitignore`.

## Credits and disclaimer
- Weather data from [Open-Meteo.com](https://open-meteo.com/) (CC BY 4.0, free for non-commercial use).
- This project is not affiliated with or endorsed by Spotify, Google or Microsoft. All product names belong to their owners.

## License
MIT, see [LICENSE](LICENSE).
