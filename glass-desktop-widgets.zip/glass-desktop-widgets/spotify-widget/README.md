# Spotify Glass Widget

A rounded, translucent "now playing" bar for the Windows desktop: album art, song, artist, progress bar and previous / play-pause / next. It reads what Spotify is playing through Windows' media session, so **no login and no API key**.

## Run it
1. Install Python 3.9+ from python.org (tick "Add Python to PATH").
2. Double-click `run.bat`. The first run installs the packages; the widget appears at the bottom centre.
3. Open the Spotify desktop app and play something.

## Use it
- **Click the widget** to open Spotify (it uses the desktop app, or the web player if the app isn't installed).
- **Drag** it to move it. It remembers its position, size and colours.
- **Resize to any size:** drag any edge or corner, or hold Ctrl and scroll the mouse wheel. Nothing ever disappears: like Apple's widgets, the layout re-arranges itself for the shape you make.
  - **Wide:** cover, then title / artist / progress, then the buttons on the right.
  - **Medium:** cover on the left, the buttons move under the text.
  - **Tall or square:** cover on top, everything else stacked below and centred.
  
  Everything scales together; extra width goes to the text and extra height to the cover. There is no maximum size. The minimum is 190 x 66 pixels, because the text would be too small to read below that.
- **Right-click** for the menu:
  - **Color**: presets (Glass, Dark, Black, Maroon, Pink, Ocean, Forest, Purple, Spotify green) or **Custom color…**
  - **Opacity**: a slider from almost clear to solid.
  - **Text color**: Automatic (white on dark, black on light), White or Black.
  - **Bigger / Smaller / Reset size**, **Quit**.
- Start with Windows: press `Win + R`, type `shell:startup`, and put a shortcut to `run.bat` there.

## Customize in the code
The top of `spotify_widget.py` has the defaults: starting size, corner `RADIUS`, text translucency (`TITLE_ALPHA`, `ARTIST_ALPHA`) and `KEEP_ON_BOTTOM` (True = sits on the desktop behind windows, False = floats on top).

Preview without Spotify: `python spotify_widget.py --demo`
