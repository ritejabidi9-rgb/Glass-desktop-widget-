"""
Spotify Glass Widget
--------------------
A rounded, translucent "now playing" bar for the Windows desktop.
It reads whatever Spotify is playing through Windows' media session (no login,
no API keys) and gives you prev / play-pause / next.

Run:      pythonw spotify_widget.py
Preview:  python spotify_widget.py --demo     (fake song, works on any OS)

Click it to open Spotify. Drag it to move it. Drag any edge/corner (or Ctrl + mouse wheel) to resize
to ANY size - the text and buttons adapt. Right-click for colour, opacity and size options.
It remembers its position, size and colours.
"""
import asyncio
import json
import os
import sys
import threading
import time
import webbrowser
from datetime import datetime, timezone
from pathlib import Path

from PyQt6.QtCore import QBuffer, QIODevice, QObject, QPointF, QRectF, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import (QBrush, QColor, QFont, QFontMetrics, QGuiApplication, QLinearGradient,
                         QPainter, QPainterPath, QPen, QPixmap, QPolygonF)
from PyQt6.QtWidgets import (QApplication, QColorDialog, QHBoxLayout, QLabel, QMenu, QSlider, QWidget,
                             QWidgetAction)

# ----------------------------------------------------------------------------
# Settings – tweak freely
# ----------------------------------------------------------------------------
APP_FILTER = "spotify"      # only show this app ("" = any media player)
WIDTH, HEIGHT = 560, 104    # widget size in pixels
RADIUS = 32                 # corner roundness
BOTTOM_MARGIN = 28          # gap above the taskbar (first launch only)
KEEP_ON_BOTTOM = True       # True = sits on the desktop like part of the wallpaper
GLASS_TOP, GLASS_BOTTOM = 58, 26   # background opacity (0-255), top -> bottom
TITLE_ALPHA, ARTIST_ALPHA = 220, 140   # text translucency (0-255)
CONFIG = Path.home() / ".spotify_glass_widget.json"

EMPTY = dict(available=False, title="Nothing playing", artist="Open Spotify and press play",
             playing=False, position=0.0, duration=0.0, art=None)


# ----------------------------------------------------------------------------
# Backends
# ----------------------------------------------------------------------------
class WinMediaBackend(QObject):
    """Reads the current Spotify session from Windows (System Media Transport Controls)."""
    updated = pyqtSignal(dict)

    def __init__(self):
        super().__init__()
        self._loop = asyncio.new_event_loop()
        self._manager = None
        self._api = None
        threading.Thread(target=self._thread_main, daemon=True).start()

    def _thread_main(self):
        asyncio.set_event_loop(self._loop)
        try:  # imported here so WinRT starts up on this worker thread
            from winrt.windows.media.control import (
                GlobalSystemMediaTransportControlsSessionManager as Manager,
                GlobalSystemMediaTransportControlsSessionPlaybackStatus as Status)
            from winrt.windows.storage.streams import Buffer, DataReader, InputStreamOptions
            self._api = dict(Manager=Manager, Status=Status, Buffer=Buffer,
                             DataReader=DataReader, Options=InputStreamOptions)
        except Exception:
            while True:  # keep re-sending so the message shows even if the window opens late
                self.updated.emit(dict(EMPTY, title="Missing packages",
                                       artist="Run run.bat once to install them"))
                time.sleep(1.0)
        self._loop.run_until_complete(self._poll())

    def _pick(self):
        for s in self._manager.get_sessions():
            if APP_FILTER in (s.source_app_user_model_id or "").lower():
                return s
        return None

    async def _read_art(self, ref):
        if ref is None:
            return None
        try:
            stream = await ref.open_read_async()
            buf = self._api["Buffer"](5_000_000)
            await stream.read_async(buf, buf.capacity, self._api["Options"].READ_AHEAD)
            reader = self._api["DataReader"].from_buffer(buf)
            data = bytearray(buf.length)
            reader.read_bytes(data)
            return bytes(data)
        except Exception:
            return None

    async def _poll(self):
        self._manager = await self._api["Manager"].request_async()
        last_key, art = None, None
        while True:
            state = dict(EMPTY)
            try:
                session = self._pick()
                if session is not None:
                    props = await session.try_get_media_properties_async()
                    key = (props.title, props.artist, props.album_title)
                    if key != last_key or art is None:
                        art = await self._read_art(props.thumbnail)
                        last_key = key
                    playing = session.get_playback_info().playback_status == self._api["Status"].PLAYING
                    tl = session.get_timeline_properties()
                    pos = tl.position.total_seconds()
                    dur = (tl.end_time - tl.start_time).total_seconds()
                    if playing:
                        try:
                            pos += (datetime.now(timezone.utc) - tl.last_updated_time).total_seconds()
                        except Exception:
                            pass
                    dur = max(dur, 0.0)
                    state.update(available=True, title=props.title or "Unknown title",
                                 artist=props.artist or "", playing=playing,
                                 position=max(0.0, min(pos, dur)) if dur else 0.0,
                                 duration=dur, art=art)
            except Exception as exc:  # never let the poll loop die
                print("poll error:", exc)
            self.updated.emit(state)
            await asyncio.sleep(1.0)

    def command(self, name):
        if self._manager is None:
            return

        async def run():
            s = self._pick()
            if s is None:
                return
            await {"toggle": s.try_toggle_play_pause_async,
                   "next": s.try_skip_next_async,
                   "prev": s.try_skip_previous_async}[name]()

        asyncio.run_coroutine_threadsafe(run(), self._loop)


class DemoBackend(QObject):
    """Fake player so you can preview the look on any computer."""
    updated = pyqtSignal(dict)

    def __init__(self):
        super().__init__()
        pm = QPixmap(300, 300)
        g = QLinearGradient(0, 0, 300, 300)
        g.setColorAt(0, QColor("#ff9a8b"))
        g.setColorAt(0.5, QColor("#c2185b"))
        g.setColorAt(1, QColor("#311b92"))
        p = QPainter(pm)
        p.fillRect(pm.rect(), QBrush(g))
        p.end()
        buf = QBuffer()
        buf.open(QIODevice.OpenModeFlag.WriteOnly)
        pm.save(buf, "PNG")
        self._art = bytes(buf.data())
        self._playing, self._pos, self._t = True, 83.0, time.monotonic()
        t = QTimer(self)
        t.timeout.connect(self._emit)
        t.start(1000)
        QTimer.singleShot(50, self._emit)

    def _emit(self):
        now = time.monotonic()
        if self._playing:
            self._pos += now - self._t
        self._t = now
        self.updated.emit(dict(available=True, title="Midnight Drive", artist="Demo Artist",
                               playing=self._playing, position=self._pos, duration=214.0,
                               art=self._art))

    def command(self, name):
        if name == "toggle":
            self._playing = not self._playing
        self._emit()


# ----------------------------------------------------------------------------
# The widget
# ----------------------------------------------------------------------------
def white(a):
    return QColor(255, 255, 255, int(a))


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


# (color, opacity 0-255) presets for the right-click menu
PRESETS = {
    "Glass": ((255, 255, 255), 58),
    "Dark": ((20, 20, 24), 170),
    "Black": ((0, 0, 0), 150),
    "Maroon": ((95, 8, 14), 190),
    "Pink": ((255, 170, 205), 150),
    "Ocean": ((18, 56, 108), 175),
    "Forest": ((20, 80, 50), 175),
    "Purple": ((80, 40, 130), 170),
    "Spotify green": ((30, 215, 96), 190),
}


def _controls(x_left, cy, u):
    """Prev / play / next cluster (9u wide) starting at x_left, centred on cy."""
    side, d, gc = 2.6 * u, 3.2 * u, 0.3 * u
    return ((x_left, cy - side / 2, side, side),
            (x_left + side + gc, cy - d / 2, d, d),
            (x_left + side + gc + d + gc, cy - side / 2, side, side))


def compute_layout(w, h):
    """Where everything goes for ANY widget size - and nothing is ever hidden.

    Like Apple's widgets, the arrangement changes with the shape while every element stays:
      wide   (H): [cover] [title / artist / progress] [prev play next]
      medium (M): [cover] [title / artist / progress / prev play next under the text]
      tall   (V): cover on top, then title, artist, progress and the buttons stacked below
    Each shape is designed in units `u`; the widget picks the shape that gives the biggest `u`,
    so everything is as large as it can be. Extra width goes to the text; extra height to the cover.
    Pure maths (no Qt), so it can be tested anywhere.
    """
    w, h = float(w), float(h)
    cands = [(min(w / 25.0, h / 8.0), 0, "H"), (min(w / 20.8, h / 10.8), -1, "M"), (min(w / 11.0, h / 19.8), -2, "V")]
    u, _, fam = max(cands, key=lambda c: (round(c[0], 3), c[1]))
    L = dict(fam=fam, u=u, d=3.2 * u, align="left", radius=min(2.5 * u, h / 2.0))

    if fam == "H":
        A, cy = 6 * u, h / 2.0
        y0 = (h - A) / 2.0
        L["art"] = (u, y0, A, A)
        L["prev"], L["play"], L["next"] = _controls(w - 10 * u, cy, u)
        x, tw = 8 * u, w - 19 * u
        ty = cy - 2.25 * u
        L["title"] = (x, ty, tw, 1.9 * u)
        L["artist"] = (x, ty + 1.9 * u, tw, 1.4 * u)
        L["bar"] = (x, ty + 4.2 * u, tw, clamp(0.3 * u, 2, 7))
        L["title_px"], L["artist_px"] = 1.35 * u, 1.0 * u
    elif fam == "M":
        A = 8.8 * u
        y0 = (h - A) / 2.0
        L["art"] = (u, y0, A, A)
        x, tw = 10.8 * u, w - 11.8 * u
        L["title"] = (x, y0, tw, 2.0 * u)
        L["artist"] = (x, y0 + 2.0 * u, tw, 1.5 * u)
        L["bar"] = (x, y0 + 4.3 * u, tw, clamp(0.3 * u, 2, 7))
        L["prev"], L["play"], L["next"] = _controls(x + (tw - 9 * u) / 2.0, y0 + 7.2 * u, u)
        L["title_px"], L["artist_px"] = 1.45 * u, 1.1 * u
    else:  # "V"
        cw = w - 2 * u
        extra = max(0.0, h - 19.8 * u)
        S = min(8 * u + extra, cw)
        top = (h - (S + 9.8 * u)) / 2.0
        L["art"] = ((w - S) / 2.0, top, S, S)
        y = top + S + u
        L["title"] = (u, y, cw, 2.0 * u)
        L["artist"] = (u, y + 2.0 * u, cw, 1.5 * u)
        L["bar"] = (u, y + 4.3 * u, cw, clamp(0.3 * u, 2, 7))
        L["prev"], L["play"], L["next"] = _controls((w - 9 * u) / 2.0, y + 7.2 * u, u)
        L["title_px"], L["artist_px"] = 1.45 * u, 1.1 * u
        L["align"] = "center"
    L["art_radius"] = clamp(L["art"][2] * 0.22, 3, 40)
    return L


class Player(QWidget):
    EDGE_MAX = 9  # px grab zone for resizing

    def __init__(self, backend):
        super().__init__()
        flags = Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool
        if KEEP_ON_BOTTOM:
            flags |= Qt.WindowType.WindowStaysOnBottomHint
        self.setWindowFlags(flags)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setMouseTracking(True)
        self.setMinimumSize(190, 66)                      # below this the text would be unreadable; no maximum
        self.setToolTip("Click: open Spotify   ·   Drag: move   ·   Right-click: options")
        self.cfg = self._load_cfg()
        self.resize(int(self.cfg.get("w") or WIDTH), int(self.cfg.get("h") or HEIGHT))

        self.backend = backend
        self.state, self.state_time = dict(EMPTY), time.monotonic()
        self.art_bytes, self.art_pix = None, None
        self.hover, self._press = None, None
        backend.updated.connect(self.on_update)

        self.tick = QTimer(self)
        self.tick.timeout.connect(self._tick)
        self.tick.start(250)
        self.save_timer = QTimer(self)
        self.save_timer.setSingleShot(True)
        self.save_timer.timeout.connect(self._save_cfg)
        self._restore_pos()

    # -- settings ---------------------------------------------------------------
    def _load_cfg(self):
        cfg = {"color": [255, 255, 255], "alpha": GLASS_TOP, "text": "auto"}
        try:
            cfg.update(json.loads(CONFIG.read_text()))
        except Exception:
            pass
        return cfg

    def _save_cfg(self):
        self.cfg.update(x=self.x(), y=self.y(), w=self.width(), h=self.height())
        try:
            CONFIG.write_text(json.dumps(self.cfg))
        except OSError:
            pass

    def _fg(self):
        """Text colour: white on dark, near-black on light (or forced from the menu)."""
        c, a = self.cfg["color"], int(self.cfg["alpha"])
        lum = 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]
        eff = lum * (a / 255.0) + 40 * (1 - a / 255.0)    # how bright it looks over a typical dark wallpaper
        mode = self.cfg.get("text", "auto")
        dark = mode == "black" or (mode == "auto" and eff > 150)
        return (QColor(20, 20, 24) if dark else QColor(255, 255, 255)), dark

    def set_look(self, color=None, alpha=None, text=None):
        if color is not None:
            self.cfg["color"] = list(color)
        if alpha is not None:
            self.cfg["alpha"] = int(alpha)
        if text is not None:
            self.cfg["text"] = text
        self.save_timer.start(400)
        self.update()

    # -- state -----------------------------------------------------------------
    def on_update(self, state):
        self.state, self.state_time = state, time.monotonic()
        if state.get("art") != self.art_bytes:
            self.art_bytes = state.get("art")
            pm = QPixmap()
            self.art_pix = pm if self.art_bytes and pm.loadFromData(self.art_bytes) else None
        self.update()

    def _tick(self):
        if self.state["playing"]:
            self.update()

    def _progress(self):
        s = self.state
        if not s["duration"]:
            return 0.0
        pos = s["position"] + ((time.monotonic() - self.state_time) if s["playing"] else 0)
        return max(0.0, min(pos / s["duration"], 1.0))

    def _hit(self, pos):
        L = compute_layout(self.width(), self.height())
        pt = QPointF(pos)
        for name in ("prev", "play", "next"):
            r = L[name]
            if r and QRectF(*r).contains(pt):
                return name
        return None

    # -- painting --------------------------------------------------------------
    def paintEvent(self, _):
        L = compute_layout(self.width(), self.height())
        s = self.state
        fg, dark = self._fg()
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        p.setRenderHint(QPainter.RenderHint.TextAntialiasing)

        # glass body (your colour + opacity)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        c, a = self.cfg["color"], int(self.cfg["alpha"])
        grad = QLinearGradient(r.topLeft(), r.bottomLeft())
        grad.setColorAt(0, QColor(c[0], c[1], c[2], a))
        grad.setColorAt(1, QColor(c[0], c[1], c[2], int(a * 0.45)))
        p.setBrush(QBrush(grad))
        edge = QColor(fg.red(), fg.green(), fg.blue(), 80 if not dark else 60)
        p.setPen(QPen(edge, 1.2))
        p.drawRoundedRect(r, L["radius"], L["radius"])

        def col(alpha):
            return QColor(fg.red(), fg.green(), fg.blue(), int(alpha))

        # album art
        if L["art"]:
            art = QRectF(*L["art"])
            clip = QPainterPath()
            clip.addRoundedRect(art, L["art_radius"], L["art_radius"])
            p.save()
            p.setClipPath(clip)
            if self.art_pix is not None:
                scaled = self.art_pix.scaled(art.size().toSize(),
                                             Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                                             Qt.TransformationMode.SmoothTransformation)
                p.drawPixmap(art.topLeft(), scaled,
                             QRectF((scaled.width() - art.width()) / 2, (scaled.height() - art.height()) / 2,
                                    art.width(), art.height()))
            else:
                p.fillRect(art, col(40))
                p.setPen(col(150))
                p.setFont(self._font(max(8, int(art.height() * 0.4))))
                p.drawText(art, Qt.AlignmentFlag.AlignCenter, "♪")
            p.restore()

        # text (translucent). Both lines are always there; the font shrinks to fit the width.
        al = Qt.AlignmentFlag.AlignHCenter if L["align"] == "center" else Qt.AlignmentFlag.AlignLeft
        flags = al | Qt.AlignmentFlag.AlignVCenter
        tr, ar = QRectF(*L["title"]), QRectF(*L["artist"])
        tf = self.fit_font(s["title"], max(9, L["title_px"]), tr.width(), True, 8)
        af = self.fit_font(s["artist"], max(8, L["artist_px"]), ar.width(), False, 7)
        p.setFont(tf); p.setPen(col(TITLE_ALPHA))
        p.drawText(tr, flags, QFontMetrics(tf).elidedText(s["title"], Qt.TextElideMode.ElideRight, int(tr.width())))
        p.setFont(af); p.setPen(col(ARTIST_ALPHA))
        p.drawText(ar, flags, QFontMetrics(af).elidedText(s["artist"], Qt.TextElideMode.ElideRight, int(ar.width())))

        # progress bar
        if L["bar"]:
            bar = QRectF(*L["bar"])
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(col(48))
            p.drawRoundedRect(bar, bar.height() / 2, bar.height() / 2)
            if s["duration"]:
                filled = QRectF(bar.x(), bar.y(), max(bar.height(), bar.width() * self._progress()), bar.height())
                p.setBrush(col(200))
                p.drawRoundedRect(filled, bar.height() / 2, bar.height() / 2)

        # controls
        d = L["d"]
        if L["prev"]:
            self._icon_prev(p, QRectF(*L["prev"]).center(), d * 0.18, col(255 if self.hover == "prev" else 190))
            self._icon_next(p, QRectF(*L["next"]).center(), d * 0.18, col(255 if self.hover == "next" else 190))
        if L["play"]:
            pr = QRectF(*L["play"])
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(col(70 if self.hover == "play" else 42))
            p.drawEllipse(pr)
            (self._icon_pause if s["playing"] else self._icon_play)(p, pr.center(), d * 0.2, col(245))

    def fit_font(self, text, px, width, bold, floor):
        """Largest font (not below `floor`) in which `text` fits `width`."""
        px = int(px)
        f = self._font(px, bold)
        while px > floor and QFontMetrics(f).horizontalAdvance(text) > width:
            px -= 1
            f = self._font(px, bold)
        return f

    @staticmethod
    def _font(px, bold=False):
        f = QFont()
        f.setFamilies(["Segoe UI Variable Display", "Segoe UI", "Helvetica Neue", "Arial"])
        f.setPixelSize(max(6, int(px)))
        f.setWeight(QFont.Weight.DemiBold if bold else QFont.Weight.Normal)
        return f

    @staticmethod
    def _icon_play(p, c, s, col):
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(col)
        p.drawPolygon(QPolygonF([QPointF(c.x() - s * .45, c.y() - s * .75),
                                 QPointF(c.x() - s * .45, c.y() + s * .75),
                                 QPointF(c.x() + s * .8, c.y())]))

    @staticmethod
    def _icon_pause(p, c, s, col):
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(col)
        for dx in (-s * .55, s * .17):
            p.drawRoundedRect(QRectF(c.x() + dx, c.y() - s * .75, s * .38, s * 1.5), 1.5, 1.5)

    @staticmethod
    def _icon_next(p, c, s, col):
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(col)
        p.drawPolygon(QPolygonF([QPointF(c.x() - s, c.y() - s * .85),
                                 QPointF(c.x() - s, c.y() + s * .85),
                                 QPointF(c.x() + s * .6, c.y())]))
        p.drawRoundedRect(QRectF(c.x() + s * .72, c.y() - s * .8, s * .28, s * 1.6), 1.5, 1.5)

    @staticmethod
    def _icon_prev(p, c, s, col):
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(col)
        p.drawPolygon(QPolygonF([QPointF(c.x() + s, c.y() - s * .85),
                                 QPointF(c.x() + s, c.y() + s * .85),
                                 QPointF(c.x() - s * .6, c.y())]))
        p.drawRoundedRect(QRectF(c.x() - s, c.y() - s * .8, s * .28, s * 1.6), 1.5, 1.5)

    # -- resizing --------------------------------------------------------------
    def _edges(self, pos):
        m = clamp(min(self.width(), self.height()) / 5.0, 4, self.EDGE_MAX)
        e = Qt.Edge(0)
        if pos.x() < m:
            e |= Qt.Edge.LeftEdge
        if pos.x() > self.width() - m:
            e |= Qt.Edge.RightEdge
        if pos.y() < m:
            e |= Qt.Edge.TopEdge
        if pos.y() > self.height() - m:
            e |= Qt.Edge.BottomEdge
        return e

    @staticmethod
    def _edge_cursor(e):
        L, R = bool(e & Qt.Edge.LeftEdge), bool(e & Qt.Edge.RightEdge)
        T, B = bool(e & Qt.Edge.TopEdge), bool(e & Qt.Edge.BottomEdge)
        if (L and T) or (R and B):
            return Qt.CursorShape.SizeFDiagCursor
        if (R and T) or (L and B):
            return Qt.CursorShape.SizeBDiagCursor
        if L or R:
            return Qt.CursorShape.SizeHorCursor
        if T or B:
            return Qt.CursorShape.SizeVerCursor
        return None

    def resizeEvent(self, _):
        self.save_timer.start(600)

    def scale_by(self, factor):
        c = self.geometry().center()
        w = max(self.minimumWidth(), int(self.width() * factor))
        h = max(self.minimumHeight(), int(self.height() * factor))
        self.setGeometry(c.x() - w // 2, c.y() - h // 2, w, h)

    def reset_size(self):
        self.resize(WIDTH, HEIGHT)

    def wheelEvent(self, e):
        if e.modifiers() & Qt.KeyboardModifier.ControlModifier:
            self.scale_by(1.06 if e.angleDelta().y() > 0 else 1 / 1.06)

    # -- mouse: click opens Spotify, drag moves, edges resize -----------------------
    def open_spotify(self):
        try:
            os.startfile("spotify:")                     # opens / focuses the Spotify desktop app
        except Exception:
            webbrowser.open("https://open.spotify.com")  # not installed: use the web player

    def mouseMoveEvent(self, e):
        if self._press is not None and (e.buttons() & Qt.MouseButton.LeftButton):
            d = e.globalPosition() - self._press
            if abs(d.x()) + abs(d.y()) > 4 and self.windowHandle():
                self._press = None
                self.windowHandle().startSystemMove()
            return
        pos = e.position()
        edge_cursor = self._edge_cursor(self._edges(pos))
        hit = None if edge_cursor else self._hit(pos)
        if hit != self.hover:
            self.hover = hit
            self.update()
        if edge_cursor:
            self.setCursor(edge_cursor)
        elif hit:
            self.setCursor(Qt.CursorShape.PointingHandCursor)
        else:
            self.setCursor(Qt.CursorShape.ArrowCursor)

    def leaveEvent(self, _):
        self.hover = None
        self.update()

    def mousePressEvent(self, e):
        if e.button() != Qt.MouseButton.LeftButton or not self.windowHandle():
            return
        edges = self._edges(e.position())
        if edges:
            self.windowHandle().startSystemResize(edges)
            return
        hit = self._hit(e.position())
        if hit:
            self.backend.command({"prev": "prev", "play": "toggle", "next": "next"}[hit])
        else:
            self._press = e.globalPosition()             # click or drag? decided on move / release

    def mouseReleaseEvent(self, e):
        if self._press is not None and e.button() == Qt.MouseButton.LeftButton:
            self._press = None
            self.open_spotify()

    # -- right-click menu ------------------------------------------------------
    def contextMenuEvent(self, e):
        menu = QMenu(self)
        menu.addAction("Open Spotify", self.open_spotify)
        menu.addSeparator()
        look = menu.addMenu("Color")
        for name, (rgb, alpha) in PRESETS.items():
            look.addAction(name, lambda checked=False, rgb=rgb, alpha=alpha: self.set_look(color=rgb, alpha=alpha))
        look.addSeparator()
        look.addAction("Custom color…", self.pick_color)
        # opacity slider
        box = QWidget()
        lay = QHBoxLayout(box)
        lay.setContentsMargins(14, 4, 14, 4)
        slider = QSlider(Qt.Orientation.Horizontal)
        slider.setRange(5, 255)
        slider.setValue(int(self.cfg["alpha"]))
        slider.setFixedWidth(140)
        pct = QLabel("%d%%" % round(int(self.cfg["alpha"]) * 100 / 255))
        pct.setMinimumWidth(38)
        slider.valueChanged.connect(lambda v: (self.set_look(alpha=v), pct.setText("%d%%" % round(v * 100 / 255))))
        lay.addWidget(QLabel("Opacity"))
        lay.addWidget(slider)
        lay.addWidget(pct)
        wa = QWidgetAction(menu)
        wa.setDefaultWidget(box)
        menu.addAction(wa)
        tm = menu.addMenu("Text color")
        for name, v in (("Automatic", "auto"), ("White", "white"), ("Black", "black")):
            act = tm.addAction(name)
            act.setCheckable(True)
            act.setChecked(self.cfg.get("text", "auto") == v)
            act.triggered.connect(lambda checked=False, v=v: self.set_look(text=v))
        menu.addSeparator()
        menu.addAction("Bigger", lambda: self.scale_by(1.15))
        menu.addAction("Smaller", lambda: self.scale_by(1 / 1.15))
        menu.addAction("Reset size", self.reset_size)
        menu.addSeparator()
        menu.addAction("Quit", QApplication.quit)
        menu.exec(e.globalPos())

    def pick_color(self):
        c = self.cfg["color"]
        col = QColorDialog.getColor(QColor(c[0], c[1], c[2]), None, "Widget color")
        if col.isValid():
            self.set_look(color=(col.red(), col.green(), col.blue()))

    # -- position + size memory ------------------------------------------------
    def moveEvent(self, _):
        self.save_timer.start(600)

    def _restore_pos(self):
        try:
            x, y = int(self.cfg["x"]), int(self.cfg["y"])
            if any(s.availableGeometry().contains(x + 40, y + 40) for s in QGuiApplication.screens()):
                self.move(x, y)
                return
        except Exception:
            pass
        geo = QGuiApplication.primaryScreen().availableGeometry()
        self.move(geo.x() + (geo.width() - self.width()) // 2,
                  geo.y() + geo.height() - self.height() - BOTTOM_MARGIN)


def main():
    demo = "--demo" in sys.argv
    if not demo and sys.platform != "win32":
        print("This widget reads Windows' media session. Use --demo to preview it here.")
        return 1
    app = QApplication(sys.argv)
    backend = DemoBackend() if demo else WinMediaBackend()
    widget = Player(backend)
    widget.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
