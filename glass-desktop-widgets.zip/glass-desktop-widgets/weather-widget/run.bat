@echo off
cd /d "%~dp0"
python -m pip install -r requirements.txt --quiet --disable-pip-version-check
start "" pythonw weather_widget.py
