"""
Weather Glass Widget
--------------------
A rounded, translucent weather tile for the Windows desktop, matching the
Spotify Glass Widget. Data comes from Open-Meteo (free, no account / API key).

Run:      pythonw weather_widget.py
Preview:  python weather_widget.py --demo     (fake weather, no internet needed)

Drag it anywhere. Drag any edge/corner (or Ctrl + mouse wheel) to resize.
Right-click for the menu. It remembers its position and size.
"""
import json
import math
import sys
import threading
import urllib.parse
import urllib.request
from pathlib import Path

from PyQt6.QtCore import QObject, QPointF, QRectF, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import (QBrush, QColor, QFont, QFontMetrics, QGuiApplication, QLinearGradient,
                         QPainter, QPainterPath, QPen, QPolygonF)
from PyQt6.QtWidgets import QApplication, QMenu, QWidget

# ----------------------------------------------------------------------------
# Settings – tweak freely
# ----------------------------------------------------------------------------
CITY = "London"           # city name to look up (change me)
COUNTRY_CODE = "GB"      # narrows the search ("" = anywhere)
LATITUDE = None            # or set exact coordinates, e.g. 36.8665
LONGITUDE = None           #                                10.1647
UNITS = "celsius"          # "celsius" or "fahrenheit"
REFRESH_MINUTES = 15

WIDTH, HEIGHT = 320, 128   # default size in pixels
RADIUS = 32                # corner roundness
MARGIN = 24                # gap from the screen corner (first launch only)
KEEP_ON_BOTTOM = True      # True = sits on the desktop behind your windows
GLASS_TOP, GLASS_BOTTOM = 58, 26       # background opacity (0-255), top -> bottom
TEXT_ALPHA, SUB_ALPHA = 225, 150       # text translucency (0-255)
CONFIG = Path.home() / ".weather_glass_widget.json"

EMPTY = dict(ok=False, city="Weather", temp=None, hi=None, lo=None,
             text="Loading…", kind="cloud", day=True)


def describe(code):
    """Open-Meteo / WMO weather code -> (text, icon kind)."""
    if code == 0:
        return "Clear sky", "clear"
    if code == 1:
        return "Mainly clear", "partly"
    if code == 2:
        return "Partly cloudy", "partly"
    if code == 3:
        return "Overcast", "cloud"
    if code in (45, 48):
        return "Fog", "fog"
    if code in (51, 53, 55, 56, 57):
        return "Drizzle", "rain"
    if code in (61, 63, 65, 66, 67):
        return "Rain", "rain"
    if code in (80, 81, 82):
        return "Showers", "rain"
    if code in (71, 73, 75, 77, 85, 86):
        return "Snow", "snow"
    if code in (95, 96, 99):
        return "Thunderstorm", "storm"
    return "Unknown", "cloud"


# ----------------------------------------------------------------------------
# Backends
# ----------------------------------------------------------------------------
class WeatherBackend(QObject):
    updated = pyqtSignal(dict)

    def __init__(self):
        super().__init__()
        self._wake = threading.Event()
        self._place = None
        self._have_data = False
        threading.Thread(target=self._run, daemon=True).start()

    def refresh(self):
        self._wake.set()

    @staticmethod
    def _get(url):
        req = urllib.request.Request(url, headers={"User-Agent": "glass-weather-widget"})
        with urllib.request.urlopen(req, timeout=12) as r:
            return json.load(r)

    def _locate(self):
        if LATITUDE is not None and LONGITUDE is not None:
            return CITY or "Weather", LATITUDE, LONGITUDE
        q = {"name": CITY, "count": 1, "language": "en", "format": "json"}
        if COUNTRY_CODE:
            q["countryCode"] = COUNTRY_CODE
        hit = self._get("https://geocoding-api.open-meteo.com/v1/search?" + urllib.parse.urlencode(q))["results"][0]
        return hit["name"], hit["latitude"], hit["longitude"]

    def _run(self):
        while True:
            wait = REFRESH_MINUTES * 60
            try:
                if self._place is None:
                    self._place = self._locate()
                name, lat, lon = self._place
                q = {"latitude": lat, "longitude": lon,
                     "current": "temperature_2m,weather_code,is_day",
                     "daily": "temperature_2m_max,temperature_2m_min",
                     "timezone": "auto", "forecast_days": 1}
                if UNITS == "fahrenheit":
                    q["temperature_unit"] = "fahrenheit"
                d = self._get("https://api.open-meteo.com/v1/forecast?" + urllib.parse.urlencode(q))
                cur, day = d["current"], d["daily"]
                text, kind = describe(int(cur["weather_code"]))
                self.updated.emit(dict(ok=True, city=name, temp=round(cur["temperature_2m"]),
                                       hi=round(day["temperature_2m_max"][0]),
                                       lo=round(day["temperature_2m_min"][0]),
                                       text=text, kind=kind, day=bool(cur.get("is_day", 1))))
                self._have_data = True
            except Exception as exc:
                print("weather error:", exc)
                if not self._have_data:  # keep showing the last good reading otherwise
                    self.updated.emit(dict(EMPTY, text="Can't reach the internet"))
                wait = 60
            self._wake.wait(wait)
            self._wake.clear()


class DemoBackend(QObject):
    updated = pyqtSignal(dict)

    def __init__(self):
        super().__init__()
        QTimer.singleShot(50, lambda: self.updated.emit(
            dict(ok=True, city="London", temp=18, hi=18, lo=16, text="Partly cloudy",
                 kind="partly", day=True)))

    def refresh(self):
        pass


# ----------------------------------------------------------------------------
# Icons (drawn with the painter – no image files needed)
# ----------------------------------------------------------------------------
def white(a):
    return QColor(255, 255, 255, int(a))


def cloud_path(r):
    x, y, w, h = r.x(), r.y(), r.width(), r.height()
    path = QPainterPath()
    path.addRoundedRect(QRectF(x + .08 * w, y + .50 * h, .84 * w, .34 * h), .17 * h, .17 * h)
    path.addEllipse(QRectF(x + .16 * w, y + .34 * h, .36 * w, .40 * h))
    path.addEllipse(QRectF(x + .34 * w, y + .18 * h, .42 * w, .46 * h))
    path.addEllipse(QRectF(x + .58 * w, y + .36 * h, .30 * w, .34 * h))
    return path.simplified()


def pen(color, width):
    return QPen(color, width, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)


def draw_sun(p, c, rad):
    col = QColor(255, 214, 102, 240)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(col)
    p.drawEllipse(c, rad, rad)
    p.setPen(pen(col, rad * .22))
    for i in range(8):
        a = i * math.pi / 4
        p.drawLine(QPointF(c.x() + math.cos(a) * rad * 1.45, c.y() + math.sin(a) * rad * 1.45),
                   QPointF(c.x() + math.cos(a) * rad * 1.85, c.y() + math.sin(a) * rad * 1.85))


def draw_moon(p, c, rad):
    box = QRectF(c.x() - rad, c.y() - rad, rad * 2, rad * 2)
    moon = QPainterPath()
    moon.addEllipse(box)
    cut = QPainterPath()
    cut.addEllipse(box.translated(rad * .65, -rad * .3))
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor(255, 244, 200, 235))
    p.drawPath(moon.subtracted(cut))


def draw_weather_icon(p, r, kind, day):
    x, y, w, h = r.x(), r.y(), r.width(), r.height()
    cloud_col = white(215)
    p.save()
    if kind == "clear":
        (draw_sun if day else draw_moon)(p, r.center(), min(w, h) * .24)
    elif kind == "partly":
        (draw_sun if day else draw_moon)(p, QPointF(x + .34 * w, y + .34 * h), w * .17)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(cloud_col)
        p.drawPath(cloud_path(QRectF(x + .2 * w, y + .22 * h, .8 * w, .8 * h)))
    elif kind == "cloud":
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(cloud_col)
        p.drawPath(cloud_path(r))
    else:  # fog / rain / snow / storm: a cloud with something under it
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(cloud_col)
        p.drawPath(cloud_path(QRectF(x, y - .05 * h, w, h)))
        if kind == "rain":
            p.setPen(pen(QColor(190, 225, 255, 230), w * .045))
            for fx in (.30, .50, .70):
                p.drawLine(QPointF(x + fx * w, y + .74 * h), QPointF(x + (fx - .05) * w, y + .93 * h))
        elif kind == "snow":
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(white(235))
            for fx in (.30, .50, .70):
                p.drawEllipse(QPointF(x + fx * w, y + .84 * h), w * .04, w * .04)
        elif kind == "fog":
            p.setPen(pen(white(190), w * .05))
            for fy in (.80, .92):
                p.drawLine(QPointF(x + .22 * w, y + fy * h), QPointF(x + .78 * w, y + fy * h))
        elif kind == "storm":
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(255, 214, 102, 245))
            p.drawPolygon(QPolygonF([QPointF(x + .52 * w, y + .62 * h), QPointF(x + .38 * w, y + .84 * h),
                                     QPointF(x + .49 * w, y + .84 * h), QPointF(x + .43 * w, y + 1.0 * h),
                                     QPointF(x + .64 * w, y + .76 * h), QPointF(x + .52 * w, y + .76 * h)]))
    p.restore()


# ----------------------------------------------------------------------------
# The widget
# ----------------------------------------------------------------------------
class Weather(QWidget):
    EDGE = 9  # px grab zone for resizing

    def __init__(self, backend):
        super().__init__()
        flags = Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool
        if KEEP_ON_BOTTOM:
            flags |= Qt.WindowType.WindowStaysOnBottomHint
        self.setWindowFlags(flags)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setMouseTracking(True)
        self.setMinimumSize(200, 64)
        self.resize(WIDTH, HEIGHT)
        self._fixing = False

        self.backend = backend
        self.state = dict(EMPTY)
        backend.updated.connect(self.on_update)

        self.save_timer = QTimer(self)
        self.save_timer.setSingleShot(True)
        self.save_timer.timeout.connect(self._save_pos)

        self._restore_pos()
        QTimer.singleShot(1500, backend.refresh)  # in case the first reading came before we listened

    def on_update(self, state):
        self.state = state
        self.update()

    # -- painting (everything scales with the widget's height) ------------------
    def _u(self):
        return self.height() / HEIGHT

    @staticmethod
    def _font(px, bold=False):
        f = QFont()
        f.setFamilies(["Segoe UI Variable Display", "Segoe UI", "Helvetica Neue", "Arial"])
        f.setPixelSize(max(7, int(px)))
        f.setWeight(QFont.Weight.DemiBold if bold else QFont.Weight.Normal)
        return f

    def paintEvent(self, _):
        u, s = self._u(), self.state
        w, h = self.width(), self.height()
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.TextAntialiasing)

        # glass body
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        radius = min(RADIUS * u, r.height() / 2)
        grad = QLinearGradient(r.topLeft(), r.bottomLeft())
        grad.setColorAt(0, white(GLASS_TOP))
        grad.setColorAt(1, white(GLASS_BOTTOM))
        p.setBrush(QBrush(grad))
        p.setPen(QPen(white(80), 1.2))
        p.drawRoundedRect(r, radius, radius)

        # icon
        icon = 76 * u
        draw_weather_icon(p, QRectF(16 * u, (h - icon) / 2, icon, icon), s["kind"], s["day"])

        left = 104 * u
        L = Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter
        R = Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter

        def text(rect, font, alpha, flags, value):
            p.setFont(font)
            p.setPen(white(alpha))
            p.drawText(rect, flags, QFontMetrics(font).elidedText(value, Qt.TextElideMode.ElideRight, int(rect.width())))

        room = max(w - left - 16 * u, 1)
        text(QRectF(left, 14 * u, room, 20 * u), self._font(13 * u), SUB_ALPHA, L, s["city"])
        temp = "--°" if s["temp"] is None else f"{s['temp']}°"
        p.setFont(self._font(48 * u, bold=True))
        p.setPen(white(TEXT_ALPHA))
        p.drawText(QRectF(left, 32 * u, 112 * u, 56 * u), L, temp)
        if s["hi"] is not None:
            hl = self._font(14 * u)
            hl_rect_x = w - 16 * u - 86 * u
            if hl_rect_x > left + 100 * u:
                text(QRectF(hl_rect_x, 40 * u, 86 * u, 22 * u), hl, SUB_ALPHA - 10, R, f"H: {s['hi']}°")
                text(QRectF(hl_rect_x, 62 * u, 86 * u, 22 * u), hl, SUB_ALPHA - 10, R, f"L: {s['lo']}°")
        text(QRectF(left, 92 * u, room, 20 * u), self._font(14 * u), SUB_ALPHA + 20, L, s["text"])

    # -- resizing --------------------------------------------------------------
    def _edges(self, pos):
        m, e = self.EDGE, Qt.Edge(0)
        if pos.x() < m:
            e |= Qt.Edge.LeftEdge
        if pos.x() > self.width() - m:
            e |= Qt.Edge.RightEdge
        if pos.y() < m:
            e |= Qt.Edge.TopEdge
        if pos.y() > self.height() - m:
            e |= Qt.Edge.BottomEdge
        return e

    @staticmethod
    def _edge_cursor(e):
        L, R = bool(e & Qt.Edge.LeftEdge), bool(e & Qt.Edge.RightEdge)
        T, B = bool(e & Qt.Edge.TopEdge), bool(e & Qt.Edge.BottomEdge)
        if (L and T) or (R and B):
            return Qt.CursorShape.SizeFDiagCursor
        if (R and T) or (L and B):
            return Qt.CursorShape.SizeBDiagCursor
        if L or R:
            return Qt.CursorShape.SizeHorCursor
        if T or B:
            return Qt.CursorShape.SizeVerCursor
        return None

    def resizeEvent(self, _):
        need = int(250 * self.height() / HEIGHT)  # keep the text from colliding when tall and narrow
        if self.width() < need and not self._fixing:
            self._fixing = True
            self.resize(need, self.height())
            self._fixing = False
        self.save_timer.start(600)

    def scale_by(self, factor):
        c = self.geometry().center()
        w = max(self.minimumWidth(), int(self.width() * factor))
        h = max(self.minimumHeight(), int(self.height() * factor))
        self.setGeometry(c.x() - w // 2, c.y() - h // 2, w, h)

    def reset_size(self):
        self.resize(WIDTH, HEIGHT)

    def wheelEvent(self, e):
        if e.modifiers() & Qt.KeyboardModifier.ControlModifier:
            self.scale_by(1.06 if e.angleDelta().y() > 0 else 1 / 1.06)

    # -- mouse -----------------------------------------------------------------
    def mouseMoveEvent(self, e):
        cur = self._edge_cursor(self._edges(e.position()))
        self.setCursor(cur if cur else Qt.CursorShape.ArrowCursor)

    def mousePressEvent(self, e):
        if e.button() != Qt.MouseButton.LeftButton or not self.windowHandle():
            return
        edges = self._edges(e.position())
        if edges:
            self.windowHandle().startSystemResize(edges)
        else:
            self.windowHandle().startSystemMove()

    def contextMenuEvent(self, e):
        menu = QMenu(self)
        menu.addAction("Refresh now", self.backend.refresh)
        menu.addSeparator()
        menu.addAction("Bigger", lambda: self.scale_by(1.15))
        menu.addAction("Smaller", lambda: self.scale_by(1 / 1.15))
        menu.addAction("Reset size", self.reset_size)
        menu.addSeparator()
        menu.addAction("Quit", QApplication.quit)
        menu.exec(e.globalPos())

    # -- position + size memory ------------------------------------------------
    def moveEvent(self, _):
        self.save_timer.start(600)

    def _save_pos(self):
        try:
            CONFIG.write_text(json.dumps({"x": self.x(), "y": self.y(),
                                          "w": self.width(), "h": self.height()}))
        except OSError:
            pass

    def _restore_pos(self):
        try:
            cfg = json.loads(CONFIG.read_text())
            if cfg.get("w") and cfg.get("h"):
                self.resize(int(cfg["w"]), int(cfg["h"]))
            x, y = int(cfg["x"]), int(cfg["y"])
            if any(s.availableGeometry().contains(x + 40, y + 40) for s in QGuiApplication.screens()):
                self.move(x, y)
                return
        except Exception:
            pass
        geo = QGuiApplication.primaryScreen().availableGeometry()
        self.move(geo.x() + geo.width() - self.width() - MARGIN, geo.y() + MARGIN)


def main():
    demo = "--demo" in sys.argv
    app = QApplication(sys.argv)
    backend = DemoBackend() if demo else WeatherBackend()
    widget = Weather(backend)
    widget.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
