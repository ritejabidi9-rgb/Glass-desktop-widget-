# Weather Glass Widget

A rounded, translucent weather tile for the Windows desktop: temperature, today's high/low, a short description and a drawn icon. Data comes from [Open-Meteo](https://open-meteo.com/) (free, no account or API key).

## Run it
1. Install Python 3.9+ from python.org (tick "Add Python to PATH").
2. Open `weather_widget.py` and set `CITY` / `COUNTRY_CODE` at the top (or `LATITUDE` / `LONGITUDE`, and `UNITS = "fahrenheit"`).
3. Double-click `run.bat`. The widget appears in the top-right corner.

## Use it
Drag to move, drag an edge or Ctrl + mouse wheel to resize, right-click for Refresh / Bigger / Smaller / Reset size / Quit. It refreshes every 15 minutes.

Preview without internet: `python weather_widget.py --demo`

## Credit
Weather data by [Open-Meteo.com](https://open-meteo.com/) (CC BY 4.0). Open-Meteo's free service is for non-commercial use; see their terms.
