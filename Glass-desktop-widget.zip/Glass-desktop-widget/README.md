# Glass Widgets
### Your desktop, your style. Personalized, aesthetic, and easy to set up.

Lightweight glass-style desktop widgets for Windows 10/11, written in Python (PyQt6). Translucent, rounded, resizable, and fully customizable, in one standalone project with no extra software and no complicated configuration.

<!-- Add screenshots to /assets, then uncomment:
![Spotify](assets/spotify.png) ![Weather](assets/weather.png) ![Classroom](assets/classroom.png)
-->

## Widgets

| Widget | What it does | Account needed |
|---|---|---|
| [Spotify](spotify) | Now-playing bar with album art, progress, and play / pause / next | No |
| [Weather](weather) | Temperature, daily high / low, and a drawn icon (via Open-Meteo) | No |
| [Classroom](classroom) | Newest Google Classroom uploads, or recently opened files | Your own free Google key ([setup](docs/classroom-setup.md)) |

## Quick start

1. Install **Python 3.10+** from [python.org](https://www.python.org/downloads/) and tick **Add Python to PATH**.
2. Download this repo (**Code > Download ZIP**) and unzip it.
3. Double-click **`install.bat`** (one time).
4. Open a widget folder and double-click **`run.bat`**.

Weather: your location is detected automatically. To use a specific city instead, set `CITY` (and optionally `COUNTRY_CODE`) at the top of `weather/weather_widget.py`.

## Controls (all widgets)

- **Drag** to move, **drag an edge or corner** (or Ctrl + scroll) to resize.
- **Right-click** opens the same customization menu on every widget:
  - **Color:** presets (Glass, Dark, Black, Maroon, Pink, Ocean, Forest, Purple, Green) or **Custom color…**
  - **Opacity:** a slider from almost clear to solid.
  - **Text color:** Automatic (white on dark, black on light), White, or Black.
  - **Bigger / Smaller / Reset size**, and **Quit**.
- Positions and settings are remembered.
- Preview without an account: `python spotify_widget.py --demo` or `python weather_widget.py --demo`.

## Start with Windows

Press `Win + R`, type `shell:startup`, and drop a shortcut to the widget's `run.bat` there. For the Classroom widget, `classroom/start_with_windows.bat` does it for you.

## Customizing

Defaults (corner radius, text transparency, always-on-desktop, units) sit at the top of each widget's `.py` file.

## Notes

- **Windows only.** The Spotify widget reads the Windows media session.
- **Weather location:** by default the widget asks a free IP-location service (ipwho.is, with ipapi.co and geojs.io as backups) for your approximate location, which means your IP address is shared with them. It's only city-level accurate and can be off. Set `CITY` or `LATITUDE` / `LONGITUDE` to avoid the lookup.
- **Smart App Control** may block Python scripts. Allow Python through it, or turn it off (on many versions it cannot be turned back on without reinstalling Windows).
- **Early version.** Tested on one PC, so expect rough edges. Please open an issue with a screenshot or the error text. The Classroom widget also writes `classroom/error.log`.
- Never upload `credentials.json` or `token.json`. The `.gitignore` already blocks them.

## Credits

Weather data by [Open-Meteo.com](https://open-meteo.com/) (CC BY 4.0, non-commercial use). Not affiliated with Spotify, Google, or Microsoft.

## License

MIT, see [LICENSE](LICENSE).
