@echo off
cd /d "%~dp0"
where pyw >nul 2>nul && (start "" pyw spotify_widget.py & exit /b)
start "" pythonw spotify_widget.py
