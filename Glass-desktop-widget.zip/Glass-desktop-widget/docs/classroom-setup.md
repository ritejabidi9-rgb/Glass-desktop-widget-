# Classroom widget setup

The widget needs your own free Google key (about 5 minutes, one time). Nobody's key is included: you sign in with your own account, so your data stays between you and Google.

## Connect Google Classroom

1. Go to [console.cloud.google.com](https://console.cloud.google.com) and create a project (any name).
2. **APIs & Services > Library**, search **Google Classroom API**, click **Enable**.
3. **OAuth consent screen** (or **Google Auth Platform**): choose **External**, fill in the app name and your email, and save.
4. Under **Test users**, add the exact Google account you use for Classroom.
5. **Credentials > Create credentials > OAuth client ID > Desktop app**, then download the JSON.
6. Rename it to `credentials.json` and put it in the `classroom` folder.
7. Run the widget and click **Connect Google Classroom**. If Google says the app isn't verified, click **Advanced > Go to (your app)**. It's your own app, so this is expected.

Optional: press **Publish app** on the consent screen so you don't have to reconnect every 7 days.

## Troubleshooting

**"Access blocked" / "Error 403: access_denied"**: your account isn't on the Test users list. Add it (step 4), delete `token.json`, and connect again. If you use two accounts, add both.

**School or work account**: the administrator may block third-party apps. Right-click the widget and choose **Show recent files instead**.

## Using the widget

- Drag empty parts of the card to move it, drag any edge to resize.
- The round button refreshes (and pins a file in recent-files mode).
- Right-click for refresh, disconnect, switching between Classroom and recent files, plus the same color, opacity, text color, and size options as the other widgets.

## Keep your keys private

`credentials.json` and `token.json` are secrets for your Google account. Never upload or share them. If they leak, delete the OAuth client in the Google Cloud console and revoke the app under Google Account > Security > Third-party access, then create a new key.
