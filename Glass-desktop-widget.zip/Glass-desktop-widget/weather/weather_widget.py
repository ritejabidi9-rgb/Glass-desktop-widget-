"""
Weather Glass Widget
--------------------
A rounded, translucent weather tile for the Windows desktop, matching the
Spotify Glass Widget. Data comes from Open-Meteo (free, no account / API key).

Run:      pythonw weather_widget.py
Preview:  python weather_widget.py --demo     (fake weather, no internet needed)

Drag it anywhere. Drag any edge/corner (or Ctrl + mouse wheel) to resize.
Right-click for colour, opacity, text colour and size options (same as the Spotify widget).
It remembers its position, size and look.
"""
import json
import math
import sys
import threading
import time
import urllib.parse
import urllib.request
from pathlib import Path

from PyQt6.QtCore import QObject, QPointF, QRectF, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import (QBrush, QColor, QFont, QFontMetrics, QGuiApplication, QLinearGradient,
                         QPainter, QPainterPath, QPen, QPolygonF)
from PyQt6.QtWidgets import (QApplication, QColorDialog, QHBoxLayout, QLabel, QMenu, QSlider, QWidget,
                             QWidgetAction)

# ----------------------------------------------------------------------------
# Settings – tweak freely
# ----------------------------------------------------------------------------
CITY = ""                  # empty = detect my location automatically; or a city name, e.g. "Tunis"
COUNTRY_CODE = ""          # optional, narrows a CITY search (e.g. "TN")
LATITUDE = None            # or set exact coordinates, e.g. 36.8665
LONGITUDE = None           #                                10.1647
UNITS = "celsius"          # "celsius" or "fahrenheit"
REFRESH_MINUTES = 15

WIDTH, HEIGHT = 320, 128   # default size in pixels
RADIUS = 32                # corner roundness
MARGIN = 24                # gap from the screen corner (first launch only)
KEEP_ON_BOTTOM = True      # True = sits on the desktop behind your windows
GLASS_TOP, GLASS_BOTTOM = 58, 26       # background opacity (0-255), top -> bottom
TEXT_ALPHA, SUB_ALPHA = 225, 150       # text translucency (0-255)
CONFIG = Path.home() / ".weather_glass_widget.json"
LOCATION_CACHE = Path.home() / ".weather_glass_location.json"   # last automatically detected place

EMPTY = dict(ok=False, city="Weather", temp=None, hi=None, lo=None,
             text="Loading…", kind="cloud", day=True)

# (color, opacity 0-255) presets for the right-click menu
PRESETS = {
    "Glass": ((255, 255, 255), 58),
    "Dark": ((20, 20, 24), 170),
    "Black": ((0, 0, 0), 150),
    "Maroon": ((95, 8, 14), 190),
    "Pink": ((255, 170, 205), 150),
    "Ocean": ((18, 56, 108), 175),
    "Forest": ((20, 80, 50), 175),
    "Purple": ((80, 40, 130), 170),
    "Green": ((30, 215, 96), 190),
}


def describe(code):
    """Open-Meteo / WMO weather code -> (text, icon kind)."""
    if code == 0:
        return "Clear sky", "clear"
    if code == 1:
        return "Mainly clear", "partly"
    if code == 2:
        return "Partly cloudy", "partly"
    if code == 3:
        return "Overcast", "cloud"
    if code in (45, 48):
        return "Fog", "fog"
    if code in (51, 53, 55, 56, 57):
        return "Drizzle", "rain"
    if code in (61, 63, 65, 66, 67):
        return "Rain", "rain"
    if code in (80, 81, 82):
        return "Showers", "rain"
    if code in (71, 73, 75, 77, 85, 86):
        return "Snow", "snow"
    if code in (95, 96, 99):
        return "Thunderstorm", "storm"
    return "Unknown", "cloud"


# ----------------------------------------------------------------------------
# Backends
# ----------------------------------------------------------------------------
class WeatherBackend(QObject):
    updated = pyqtSignal(dict)

    def __init__(self):
        super().__init__()
        self._wake = threading.Event()
        self._place, self._placed_at, self._relocate = None, 0.0, False
        self._have_data = False
        threading.Thread(target=self._run, daemon=True).start()

    def refresh(self):
        self._relocate = True            # also re-detect the location (automatic mode)
        self._wake.set()

    @staticmethod
    def _get(url):
        req = urllib.request.Request(url, headers={"User-Agent": "glass-weather-widget"})
        with urllib.request.urlopen(req, timeout=12) as r:
            return json.load(r)

    def _auto_locate(self):
        """Approximate place from your public IP address (no account, no key)."""
        for url in ("https://ipwho.is/", "https://ipapi.co/json/", "https://get.geojs.io/v1/ip/geo.json"):
            try:
                d = self._get(url)
                lat, lon = float(d["latitude"]), float(d["longitude"])
                return (d.get("city") or d.get("region") or d.get("country") or "Weather"), lat, lon
            except Exception as exc:
                print("location service failed:", url, exc)
        raise RuntimeError("could not detect your location")

    def _locate(self):
        if LATITUDE is not None and LONGITUDE is not None:
            return CITY or "Weather", LATITUDE, LONGITUDE
        if not CITY:                                     # automatic
            try:
                place = self._auto_locate()
                try:
                    LOCATION_CACHE.write_text(json.dumps(place))
                except OSError:
                    pass
                return place
            except Exception as exc:
                try:                                     # offline: reuse the last detected place
                    name, lat, lon = json.loads(LOCATION_CACHE.read_text())
                    return name, lat, lon
                except Exception:
                    raise exc
        q = {"name": CITY, "count": 1, "language": "en", "format": "json"}
        if COUNTRY_CODE:
            q["countryCode"] = COUNTRY_CODE
        hit = self._get("https://geocoding-api.open-meteo.com/v1/search?" + urllib.parse.urlencode(q))["results"][0]
        return hit["name"], hit["latitude"], hit["longitude"]

    def _run(self):
        while True:
            wait = REFRESH_MINUTES * 60
            try:
                auto = not CITY and (LATITUDE is None or LONGITUDE is None)
                stale = auto and time.monotonic() - self._placed_at > 3 * 3600    # follow you when you travel
                if self._place is None or (auto and (stale or self._relocate)):
                    self._relocate = False
                    self._place = self._locate()
                    self._placed_at = time.monotonic()
                name, lat, lon = self._place
                q = {"latitude": lat, "longitude": lon,
                     "current": "temperature_2m,weather_code,is_day",
                     "daily": "temperature_2m_max,temperature_2m_min",
                     "timezone": "auto", "forecast_days": 1}
                if UNITS == "fahrenheit":
                    q["temperature_unit"] = "fahrenheit"
                d = self._get("https://api.open-meteo.com/v1/forecast?" + urllib.parse.urlencode(q))
                cur, day = d["current"], d["daily"]
                text, kind = describe(int(cur["weather_code"]))
                self.updated.emit(dict(ok=True, city=name, temp=round(cur["temperature_2m"]),
                                       hi=round(day["temperature_2m_max"][0]),
                                       lo=round(day["temperature_2m_min"][0]),
                                       text=text, kind=kind, day=bool(cur.get("is_day", 1))))
                self._have_data = True
            except Exception as exc:
                print("weather error:", exc)
                if not self._have_data:  # keep showing the last good reading otherwise
                    self.updated.emit(dict(EMPTY, text="Can't reach the internet"))
                wait = 60
            self._wake.wait(wait)
            self._wake.clear()


class DemoBackend(QObject):
    updated = pyqtSignal(dict)

    def __init__(self):
        super().__init__()
        QTimer.singleShot(50, lambda: self.updated.emit(
            dict(ok=True, city="London", temp=18, hi=18, lo=16, text="Partly cloudy",
                 kind="partly", day=True)))

    def refresh(self):
        pass


# ----------------------------------------------------------------------------
# Icons (drawn with the painter – no image files needed)
# ----------------------------------------------------------------------------
def cloud_path(r):
    x, y, w, h = r.x(), r.y(), r.width(), r.height()
    path = QPainterPath()
    path.addRoundedRect(QRectF(x + .08 * w, y + .50 * h, .84 * w, .34 * h), .17 * h, .17 * h)
    path.addEllipse(QRectF(x + .16 * w, y + .34 * h, .36 * w, .40 * h))
    path.addEllipse(QRectF(x + .34 * w, y + .18 * h, .42 * w, .46 * h))
    path.addEllipse(QRectF(x + .58 * w, y + .36 * h, .30 * w, .34 * h))
    return path.simplified()


def pen(color, width):
    return QPen(color, width, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)


def draw_sun(p, c, rad):
    col = QColor(255, 214, 102, 240)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(col)
    p.drawEllipse(c, rad, rad)
    p.setPen(pen(col, rad * .22))
    for i in range(8):
        a = i * math.pi / 4
        p.drawLine(QPointF(c.x() + math.cos(a) * rad * 1.45, c.y() + math.sin(a) * rad * 1.45),
                   QPointF(c.x() + math.cos(a) * rad * 1.85, c.y() + math.sin(a) * rad * 1.85))


def draw_moon(p, c, rad):
    box = QRectF(c.x() - rad, c.y() - rad, rad * 2, rad * 2)
    moon = QPainterPath()
    moon.addEllipse(box)
    cut = QPainterPath()
    cut.addEllipse(box.translated(rad * .65, -rad * .3))
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor(255, 244, 200, 235))
    p.drawPath(moon.subtracted(cut))


def draw_weather_icon(p, r, kind, day, fg=None):
    x, y, w, h = r.x(), r.y(), r.width(), r.height()
    fg = fg or QColor(255, 255, 255)

    def tone(a):
        return QColor(fg.red(), fg.green(), fg.blue(), int(a))

    cloud_col = tone(215)
    p.save()
    if kind == "clear":
        (draw_sun if day else draw_moon)(p, r.center(), min(w, h) * .24)
    elif kind == "partly":
        (draw_sun if day else draw_moon)(p, QPointF(x + .34 * w, y + .34 * h), w * .17)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(cloud_col)
        p.drawPath(cloud_path(QRectF(x + .2 * w, y + .22 * h, .8 * w, .8 * h)))
    elif kind == "cloud":
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(cloud_col)
        p.drawPath(cloud_path(r))
    else:  # fog / rain / snow / storm: a cloud with something under it
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(cloud_col)
        p.drawPath(cloud_path(QRectF(x, y - .05 * h, w, h)))
        if kind == "rain":
            p.setPen(pen(QColor(190, 225, 255, 230), w * .045))
            for fx in (.30, .50, .70):
                p.drawLine(QPointF(x + fx * w, y + .74 * h), QPointF(x + (fx - .05) * w, y + .93 * h))
        elif kind == "snow":
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(tone(235))
            for fx in (.30, .50, .70):
                p.drawEllipse(QPointF(x + fx * w, y + .84 * h), w * .04, w * .04)
        elif kind == "fog":
            p.setPen(pen(tone(190), w * .05))
            for fy in (.80, .92):
                p.drawLine(QPointF(x + .22 * w, y + fy * h), QPointF(x + .78 * w, y + fy * h))
        elif kind == "storm":
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(255, 214, 102, 245))
            p.drawPolygon(QPolygonF([QPointF(x + .52 * w, y + .62 * h), QPointF(x + .38 * w, y + .84 * h),
                                     QPointF(x + .49 * w, y + .84 * h), QPointF(x + .43 * w, y + 1.0 * h),
                                     QPointF(x + .64 * w, y + .76 * h), QPointF(x + .52 * w, y + .76 * h)]))
    p.restore()


# ----------------------------------------------------------------------------
# The widget
# ----------------------------------------------------------------------------
class Weather(QWidget):
    EDGE = 9  # px grab zone for resizing

    def __init__(self, backend):
        super().__init__()
        flags = Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool
        if KEEP_ON_BOTTOM:
            flags |= Qt.WindowType.WindowStaysOnBottomHint
        self.setWindowFlags(flags)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setMouseTracking(True)
        self.setMinimumSize(200, 64)
        self.cfg = self._load_cfg()
        self.resize(WIDTH, HEIGHT)
        self._fixing = False

        self.backend = backend
        self.state = dict(EMPTY)
        backend.updated.connect(self.on_update)

        self.save_timer = QTimer(self)
        self.save_timer.setSingleShot(True)
        self.save_timer.timeout.connect(self._save_cfg)

        self._restore_pos()
        QTimer.singleShot(1500, backend.refresh)  # in case the first reading came before we listened

    # -- settings ---------------------------------------------------------------
    def _load_cfg(self):
        cfg = {"color": [255, 255, 255], "alpha": GLASS_TOP, "text": "auto"}
        try:
            cfg.update(json.loads(CONFIG.read_text()))
        except Exception:
            pass
        return cfg

    def _save_cfg(self):
        self.cfg.update(x=self.x(), y=self.y(), w=self.width(), h=self.height())
        try:
            CONFIG.write_text(json.dumps(self.cfg))
        except OSError:
            pass

    def _fg(self):
        """Text colour: white on dark, near-black on light (or forced from the menu)."""
        c, a = self.cfg["color"], int(self.cfg["alpha"])
        lum = 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]
        eff = lum * (a / 255.0) + 40 * (1 - a / 255.0)    # how bright it looks over a typical dark wallpaper
        mode = self.cfg.get("text", "auto")
        dark = mode == "black" or (mode == "auto" and eff > 150)
        return (QColor(20, 20, 24) if dark else QColor(255, 255, 255)), dark

    def set_look(self, color=None, alpha=None, text=None):
        if color is not None:
            self.cfg["color"] = list(color)
        if alpha is not None:
            self.cfg["alpha"] = int(alpha)
        if text is not None:
            self.cfg["text"] = text
        self.save_timer.start(400)
        self.update()

    def on_update(self, state):
        self.state = state
        self.update()

    # -- painting (everything scales with the widget's height) ------------------
    def _u(self):
        return self.height() / HEIGHT

    @staticmethod
    def _font(px, bold=False):
        f = QFont()
        f.setFamilies(["Segoe UI Variable Display", "Segoe UI", "Helvetica Neue", "Arial"])
        f.setPixelSize(max(7, int(px)))
        f.setWeight(QFont.Weight.DemiBold if bold else QFont.Weight.Normal)
        return f

    def paintEvent(self, _):
        u, s = self._u(), self.state
        w, h = self.width(), self.height()
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.TextAntialiasing)
        fg, dark = self._fg()

        def col(alpha):
            return QColor(fg.red(), fg.green(), fg.blue(), int(alpha))

        # glass body (your colour + opacity)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        radius = min(RADIUS * u, r.height() / 2)
        c, a = self.cfg["color"], int(self.cfg["alpha"])
        grad = QLinearGradient(r.topLeft(), r.bottomLeft())
        grad.setColorAt(0, QColor(c[0], c[1], c[2], a))
        grad.setColorAt(1, QColor(c[0], c[1], c[2], int(a * 0.45)))
        p.setBrush(QBrush(grad))
        p.setPen(QPen(col(80 if not dark else 60), 1.2))
        p.drawRoundedRect(r, radius, radius)

        # icon
        icon = 76 * u
        draw_weather_icon(p, QRectF(16 * u, (h - icon) / 2, icon, icon), s["kind"], s["day"], fg)

        left = 104 * u
        L = Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter
        R = Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter

        def text(rect, font, alpha, flags, value):
            p.setFont(font)
            p.setPen(col(alpha))
            p.drawText(rect, flags, QFontMetrics(font).elidedText(value, Qt.TextElideMode.ElideRight, int(rect.width())))

        room = max(w - left - 16 * u, 1)
        text(QRectF(left, 14 * u, room, 20 * u), self._font(13 * u), SUB_ALPHA, L, s["city"])
        temp = "--°" if s["temp"] is None else f"{s['temp']}°"
        p.setFont(self._font(48 * u, bold=True))
        p.setPen(col(TEXT_ALPHA))
        p.drawText(QRectF(left, 32 * u, 112 * u, 56 * u), L, temp)
        if s["hi"] is not None:
            hl = self._font(14 * u)
            hl_rect_x = w - 16 * u - 86 * u
            if hl_rect_x > left + 100 * u:
                text(QRectF(hl_rect_x, 40 * u, 86 * u, 22 * u), hl, SUB_ALPHA - 10, R, f"H: {s['hi']}°")
                text(QRectF(hl_rect_x, 62 * u, 86 * u, 22 * u), hl, SUB_ALPHA - 10, R, f"L: {s['lo']}°")
        text(QRectF(left, 92 * u, room, 20 * u), self._font(14 * u), SUB_ALPHA + 20, L, s["text"])

    # -- resizing --------------------------------------------------------------
    def _edges(self, pos):
        m, e = self.EDGE, Qt.Edge(0)
        if pos.x() < m:
            e |= Qt.Edge.LeftEdge
        if pos.x() > self.width() - m:
            e |= Qt.Edge.RightEdge
        if pos.y() < m:
            e |= Qt.Edge.TopEdge
        if pos.y() > self.height() - m:
            e |= Qt.Edge.BottomEdge
        return e

    @staticmethod
    def _edge_cursor(e):
        L, R = bool(e & Qt.Edge.LeftEdge), bool(e & Qt.Edge.RightEdge)
        T, B = bool(e & Qt.Edge.TopEdge), bool(e & Qt.Edge.BottomEdge)
        if (L and T) or (R and B):
            return Qt.CursorShape.SizeFDiagCursor
        if (R and T) or (L and B):
            return Qt.CursorShape.SizeBDiagCursor
        if L or R:
            return Qt.CursorShape.SizeHorCursor
        if T or B:
            return Qt.CursorShape.SizeVerCursor
        return None

    def resizeEvent(self, _):
        need = int(250 * self.height() / HEIGHT)  # keep the text from colliding when tall and narrow
        if self.width() < need and not self._fixing:
            self._fixing = True
            self.resize(need, self.height())
            self._fixing = False
        self.save_timer.start(600)

    def scale_by(self, factor):
        c = self.geometry().center()
        w = max(self.minimumWidth(), int(self.width() * factor))
        h = max(self.minimumHeight(), int(self.height() * factor))
        self.setGeometry(c.x() - w // 2, c.y() - h // 2, w, h)

    def reset_size(self):
        self.resize(WIDTH, HEIGHT)

    def wheelEvent(self, e):
        if e.modifiers() & Qt.KeyboardModifier.ControlModifier:
            self.scale_by(1.06 if e.angleDelta().y() > 0 else 1 / 1.06)

    # -- mouse -----------------------------------------------------------------
    def mouseMoveEvent(self, e):
        cur = self._edge_cursor(self._edges(e.position()))
        self.setCursor(cur if cur else Qt.CursorShape.ArrowCursor)

    def mousePressEvent(self, e):
        if e.button() != Qt.MouseButton.LeftButton or not self.windowHandle():
            return
        edges = self._edges(e.position())
        if edges:
            self.windowHandle().startSystemResize(edges)
        else:
            self.windowHandle().startSystemMove()

    def contextMenuEvent(self, e):
        menu = QMenu(self)
        menu.addAction("Refresh now", self.backend.refresh)
        menu.addSeparator()
        look = menu.addMenu("Color")
        for name, (rgb, alpha) in PRESETS.items():
            look.addAction(name, lambda checked=False, rgb=rgb, alpha=alpha: self.set_look(color=rgb, alpha=alpha))
        look.addSeparator()
        look.addAction("Custom color…", self.pick_color)
        # opacity slider
        box = QWidget()
        lay = QHBoxLayout(box)
        lay.setContentsMargins(14, 4, 14, 4)
        slider = QSlider(Qt.Orientation.Horizontal)
        slider.setRange(5, 255)
        slider.setValue(int(self.cfg["alpha"]))
        slider.setFixedWidth(140)
        pct = QLabel("%d%%" % round(int(self.cfg["alpha"]) * 100 / 255))
        pct.setMinimumWidth(38)
        slider.valueChanged.connect(lambda v: (self.set_look(alpha=v), pct.setText("%d%%" % round(v * 100 / 255))))
        lay.addWidget(QLabel("Opacity"))
        lay.addWidget(slider)
        lay.addWidget(pct)
        wa = QWidgetAction(menu)
        wa.setDefaultWidget(box)
        menu.addAction(wa)
        tm = menu.addMenu("Text color")
        for name, v in (("Automatic", "auto"), ("White", "white"), ("Black", "black")):
            act = tm.addAction(name)
            act.setCheckable(True)
            act.setChecked(self.cfg.get("text", "auto") == v)
            act.triggered.connect(lambda checked=False, v=v: self.set_look(text=v))
        menu.addSeparator()
        menu.addAction("Bigger", lambda: self.scale_by(1.15))
        menu.addAction("Smaller", lambda: self.scale_by(1 / 1.15))
        menu.addAction("Reset size", self.reset_size)
        menu.addSeparator()
        menu.addAction("Quit", QApplication.quit)
        menu.exec(e.globalPos())

    def pick_color(self):
        c = self.cfg["color"]
        col = QColorDialog.getColor(QColor(c[0], c[1], c[2]), self, "Widget color")
        if col.isValid():
            self.set_look(color=(col.red(), col.green(), col.blue()))

    # -- position + size memory ------------------------------------------------
    def moveEvent(self, _):
        self.save_timer.start(600)

    def _restore_pos(self):
        try:
            cfg = self.cfg
            if cfg.get("w") and cfg.get("h"):
                self.resize(int(cfg["w"]), int(cfg["h"]))
            x, y = int(cfg["x"]), int(cfg["y"])
            if any(s.availableGeometry().contains(x + 40, y + 40) for s in QGuiApplication.screens()):
                self.move(x, y)
                return
        except Exception:
            pass
        geo = QGuiApplication.primaryScreen().availableGeometry()
        self.move(geo.x() + geo.width() - self.width() - MARGIN, geo.y() + MARGIN)


def main():
    demo = "--demo" in sys.argv
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)      # closing the colour dialog must not end the app
    backend = DemoBackend() if demo else WeatherBackend()
    widget = Weather(backend)
    widget.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
