@echo off
cd /d "%~dp0"
where pyw >nul 2>nul && (start "" pyw weather_widget.py & exit /b)
start "" pythonw weather_widget.py
