@echo off
cd /d "%~dp0"
where pyw >nul 2>nul && (start "" pyw classroom_widget.py & exit /b)
start "" pythonw classroom_widget.py
