@echo off
cd /d "%~dp0"
set PY=python
where py >nul 2>nul && set PY=py
%PY% -m pip install -r requirements.txt
if errorlevel 1 (
  echo Install failed. Is Python installed and on PATH?
  pause
  exit /b
)
echo.
echo Done. Open a widget folder and double-click run.bat.
pause
